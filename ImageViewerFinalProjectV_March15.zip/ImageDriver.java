public class ImageDriver {
	public static void main(String[] args) {
		ImageViewer iv = new ImageViewer();
		iv.makeFrame();
	}
}